﻿namespace TrafficJam.Tools
{
    public class Tool
    {
    }
}